Web service for acquisition from Eprints v2.1.1

About 
This software is intended for reception of records under protocol SOAP (http://www.w3.org/TR/soap/).
Now available 2 service:
1.	Service acquisition metadata about id item MetaDataServ (return metadata for item id)
2.	Service find item, the service allows us to search datasets for data objects matching specific criteria. (return list id item for pair keyword and list fields)

Installation 
1.	It is necessary to create folders �you directory eprints\cgi\soap�
In this folder to copy scripts SearchServ.cgi MetaDataServ.cgi

In directory �eprints\archives\you archive id\html\you default languge\wsdl�
Here to copy MetaDataServ.wsdl SearchServ.wsdl
2.	Replace in MetaDataServ.wsdl SearchServ.wsdl string �you.domain� 

3.	To install SOAP:: Lite from cpan (http://search.cpan.org/~mkutter/SOAP-Lite-0.710.08/)

4.	Configure auto-apache.conf having added in existing virtual a host the following 

Way for Debian (at you system to be another)


 <Directory "/usr/share/eprints3/cgi/soap /"> 
 SetHandler perl-script 
 PerlHandler ModPerl:: Registry 
 PerlSendHeader Off 
 Options ExecCGI FollowSymLinks 
 PerlHandler ServerDemo 
 PerlOptions +GlobalRequest 
 AddHandler cgi-script cgi 
 AllowOverride None 
 Options +ExecCGI-MultiViews 
 Order allow, deny 
 Allow from all 
 </Directory> 


Example of the client for testing for SearchServ
#!/usr/bin/perl 
use SOAP::Lite +trace;
use Data::Dumper; 
 # key for search
  my $key='article';
  print "SOAP::Lite = ", $SOAP::Lite::VERSION, "\n";
  my $serv = SOAP::Lite->service("http://eprints.zu.edu.ua/wsdl/SearchServ.wsdl");
  my $fields = ["title", "abstract"]; 
  my $result = $serv->searchEprint($key, $fields);
    print $result, "\n"; 
  print Dumper ($result);
  # sub routines implicitly used in the above code 
 sub SOAP::Serializer::as_ArrayOfstring{
 my ($self, $value, $name, $type, $attr) = @_; 
   return [$name, {'xsi:type' => 'array', %$attr}, $value]; 
         }     


Example of the client for testing for MetaDataServ
#!/usr/bin/perl  
use SOAP::Lite +trace;
use Data::Dumper; 
# id of eprint object
 $id = '94';
# using the file of wsdl send a value to service and get a result 
 my @res2= SOAP::Lite 
    ->service('http://eprints.zu.edu.ua/wsdl/MetaDataServ.wsdl') 
    ->getEprint(�$id�);  
# print of the got value       
  print Dumper (\@res2);

Changelog 
Version 2.0.0
Add SearchServ.cgi
Version 2.1.1
Change SearchServ.wsdl
Add SearchServ.cgi correct working with SOAP format protocol
Update documentation 

Novytskyi Oleksandr 
alex@zu.edu.ua

